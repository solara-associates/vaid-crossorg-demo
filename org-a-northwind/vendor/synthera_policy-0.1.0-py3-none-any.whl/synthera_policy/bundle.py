"""Bundle integrity verification: the hash and the signature.

Python mirror of `verify_bundle_integrity` in
`crates/synthera-policy/src/bundle_ingest.rs`.

## INTEGRITY, not admission

The Rust function this mirrors is deliberately narrower than the substrate's
publish-time `verify`. It answers only "are these the bytes that were signed,
by a key we hold?" — a property of the artefact, true forever or never true.

It does NOT re-run ADMISSION: the allowed-compiler list, the simulation
manifest, the constitution-ref binding. Those are properties of the
substrate's policy at publish time and they change, so re-running them
elsewhere would mean trimming a list silently deactivates bundles. Admission
was decided once, at publish, and audited then.

An enforcement point at a receiver is in the same position as boot hydration:
it re-checks integrity, and it does not get a vote on admission.

## What the signature actually covers

``signing_payload`` is ``bytecode_sha256|semver|tenant_id|name`` — four fields
joined by a pipe. Note what is NOT in it, because it decides what an
enforcement point may evaluate:

- `compiled_bytecode` is covered, transitively, via `bytecode_sha256`.
- `source`, `source_dsl`, `compiler_version`, `simulated_against` and
  `constitution_ref` are **not covered at all**.

So a verified signature licenses exactly one thing: executing
`compiled_bytecode`. It says nothing about the rule text in `source`. See the
module docstring of `vm.py` for why that makes bytecode the only admissible
evaluation path.
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey


class BundleVerifyError(Exception):
    """Mirrors the `BundleVerifyError` variants this function can raise."""


class BytecodeHashMismatch(BundleVerifyError):
    def __init__(self) -> None:
        super().__init__("bytecode SHA-256 hash mismatch")


class UnknownSigningKey(BundleVerifyError):
    def __init__(self, key_ref: str) -> None:
        super().__init__(f"unknown signing key reference: {key_ref}")


class InvalidBundleSignature(BundleVerifyError):
    def __init__(self) -> None:
        super().__init__("invalid Ed25519 signature")


class UnsupportedSignatureScheme(BundleVerifyError):
    def __init__(self, scheme: str) -> None:
        super().__init__(f"unsupported signature scheme: {scheme}")


@dataclass(frozen=True)
class PolicyKeyRegistry:
    """Resolves `(tenant_id, signing_key_ref)` to a raw Ed25519 public key.

    Scoping by tenant as well as by key reference is the point, mirroring
    `PolicySigningKeyRegistry`: it stops a key registered for one tenant
    verifying another tenant's bundle. A flat `key_ref -> key` map would lose
    that, so the key of this dict is the pair.
    """

    keys: dict[tuple[str, str], bytes]

    def lookup(self, tenant_id: str, signing_key_ref: str) -> bytes | None:
        return self.keys.get((tenant_id, signing_key_ref))


def signing_payload(
    *, bytecode_sha256: str, semver: str, tenant_id: str, name: str
) -> bytes:
    """The exact bytes a bundle signature covers.

    Mirror of `bundle_ingest.rs::signing_payload`, which formats
    ``"{}|{}|{}|{}"`` over bytecode hash, semver, tenant and name in that
    order. The order is wire format: reordering it invalidates every existing
    signature, so it is pinned by a test rather than left to the reader.
    """
    return f"{bytecode_sha256}|{semver}|{tenant_id}|{name}".encode("utf-8")


def bytecode_digest(compiled_bytecode: bytes) -> str:
    """Lowercase hex SHA-256, matching Rust's `format!("{:x}", ...)`."""
    return hashlib.sha256(compiled_bytecode).hexdigest()


def verify_bundle_integrity(
    bundle: dict,
    registry: PolicyKeyRegistry,
) -> None:
    """Raise unless `bundle`'s bytecode hash and signature both check out.

    `bundle` is the snake_case `PolicyBundleV1` wire form. Returns `None` on
    success and raises a `BundleVerifyError` subclass otherwise — never a
    boolean, so a caller cannot forget to branch on it.

    Order matters and matches Rust: hash first, then scheme, then key lookup,
    then signature. Checking the hash first means a corrupted bundle is named
    as corrupted rather than as badly signed.
    """
    compiled = bytes(bundle.get("compiled_bytecode") or b"")
    declared = bundle.get("bytecode_sha256", "")
    if bytecode_digest(compiled) != declared:
        raise BytecodeHashMismatch()

    scheme = bundle.get("signature_scheme", "")
    if scheme != "ed25519":
        raise UnsupportedSignatureScheme(str(scheme))

    tenant_id = bundle.get("tenant_id", "")
    key_ref = bundle.get("signing_key_ref", "")
    public_key = registry.lookup(tenant_id, key_ref)
    if public_key is None:
        raise UnknownSigningKey(key_ref)

    payload = signing_payload(
        bytecode_sha256=declared,
        semver=bundle.get("semver", ""),
        tenant_id=tenant_id,
        name=bundle.get("name", ""),
    )
    signature = bytes(bundle.get("signature") or b"")
    try:
        Ed25519PublicKey.from_public_bytes(public_key).verify(signature, payload)
    except (InvalidSignature, ValueError, TypeError) as exc:
        raise InvalidBundleSignature() from exc
