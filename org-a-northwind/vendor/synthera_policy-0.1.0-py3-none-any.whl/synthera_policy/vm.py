"""Python conformance mirror of the SYNTHERA policy bytecode VM (ADR-0014).

Byte-for-byte mirror of ``crates/synthera-policy/src/vm.rs``. Deterministic,
sandboxed, stack-based: no clock, no RNG, no I/O. Two runs over the same
bytecode and context produce the same verdict.

## Why a Python VM exists at all

An enforcement point that is not the substrate needs to reach a verdict from
the same bundle. The cross-org demo's receiver is a Python Lambda, so it has
two options: call the substrate (which puts the issuer in the request path for
every tool call, the exact shape the design avoids) or evaluate locally.

## Why it evaluates BYTECODE and not the rule source

`PolicyBundleV1.signature` covers `signing_payload()`, which is
``bytecode_sha256|semver|tenant_id|name`` — and `bytecode_sha256` is the digest
of `compiled_bytecode`. The bundle's `source` field is covered by NEITHER the
hash nor the signature.

So an enforcement point that evaluated `source` would be evaluating bytes
nothing signed: a mirror could serve a bundle with a matching hash, a valid
signature and entirely different rules, and the verifier would report
"signature verified" over rules the issuer never approved. Evaluating the
bytecode is what makes the signature mean something about the decision.

**Invariant, and the reason this module has no rule-source path at all:
`source` is documentation. Nothing may evaluate it.**

## What locks this to Rust

`conformance/policyc/*.vectors.json` — the committed golden vectors, each
carrying `bytecode_hex` plus the verdict the REAL Rust `Interpreter` produces
for 64 contexts. 256 cases over four programs, covering every opcode, both
connectives, negation, all four verdicts, and backslash/quote/multi-byte
escaping. Those files are protected: ADR-0003 r5 makes a lowering change a
compiler-version bump, so they cannot be regenerated to make a test pass.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from typing import Union

#: Compiler versions this VM will execute. Mirror of
#: `vm.rs::SUPPORTED_COMPILER_VERSIONS`. Adding one is additive (ADR-0010 r1).
SUPPORTED_COMPILER_VERSIONS: tuple[str, ...] = ("synthera-policyc 0.1.0",)

#: Resource limits. Mirror of `vm.rs`.
DEFAULT_INSTRUCTION_BUDGET = 100_000
MAX_STACK_DEPTH = 256
MAX_VALUE_SIZE_BYTES = 64 * 1024

#: Substrate-owned name table for `LoadCtx`. The compiler emits u16 indices and
#: the VM resolves them here. Order is the wire format: renumbering is a
#: breaking format change requiring a new compiler version, so this tuple is
#: not to be reordered or pruned, only appended to.
CTX_NAMES: tuple[str, ...] = ("agent_class", "tenant_id", "resource", "action")

# Opcodes. The value is the wire byte (ADR-0014).
OP_PUSH_BOOL = 0x01
OP_PUSH_STRING = 0x02
OP_PUSH_I64 = 0x03
OP_LOAD_CTX = 0x10
OP_EQ = 0x20
OP_LT = 0x21
OP_GT = 0x22
OP_LE = 0x23
OP_GE = 0x24
OP_AND = 0x30
OP_OR = 0x31
OP_NOT = 0x32
OP_JUMP_IF_FALSE = 0x40
OP_JUMP = 0x41
OP_ALLOW = 0xF0
OP_DENY = 0xF1
OP_CONSTRAIN = 0xF2
OP_ESCALATE = 0xF3

_KNOWN_OPS = frozenset(
    {
        OP_PUSH_BOOL, OP_PUSH_STRING, OP_PUSH_I64, OP_LOAD_CTX,
        OP_EQ, OP_LT, OP_GT, OP_LE, OP_GE,
        OP_AND, OP_OR, OP_NOT,
        OP_JUMP_IF_FALSE, OP_JUMP,
        OP_ALLOW, OP_DENY, OP_CONSTRAIN, OP_ESCALATE,
    }
)


class VmError(Exception):
    """Mirror of `vm.rs::VmError`.

    The message text matches the Rust `thiserror` Display strings, because the
    golden vectors record errors as ``VmError(<display>)`` — a legitimate
    recorded outcome, since an error is what the substrate maps to Escalate and
    a vector that could only hold successes would have nowhere to put a
    malformed program.
    """


def _unknown_opcode(b: int, off: int) -> VmError:
    return VmError(f"unknown opcode 0x{b:02x} at offset {off}")


def _malformed(off: int, msg: str) -> VmError:
    return VmError(f"malformed bytecode at offset {off}: {msg}")


def _type_mismatch(off: int, msg: str) -> VmError:
    return VmError(f"type mismatch at offset {off}: {msg}")


# ─── Verdicts ──────────────────────────────────────────────────────────────
# Four and only four, mirroring `PolicyDecision`. There is deliberately no
# fifth "could not decide" verdict: an error is raised, and the CALLER decides
# what an error means. For an enforcement gate that must be a refusal.


@dataclass(frozen=True)
class Allow:
    pass


@dataclass(frozen=True)
class Deny:
    reason: str


@dataclass(frozen=True)
class Escalate:
    reason: str


@dataclass(frozen=True)
class Constrain:
    conditions: tuple[str, ...]


Verdict = Union[Allow, Deny, Escalate, Constrain]


@dataclass(frozen=True)
class EvalContext:
    """The four stable names bytecode can read.

    `vm.rs` documents an `attrs` field as DOCUMENTED-BUT-NOT-READ: no opcode
    reaches it. It is omitted here rather than mirrored as dead weight, because
    a field present in a mirror reads as a field the VM consults.
    """

    agent_class: str
    tenant_id: str
    resource: str
    action: str

    def load(self, name: str) -> str:
        if name == "agent_class":
            return self.agent_class
        if name == "tenant_id":
            return self.tenant_id
        if name == "resource":
            return self.resource
        if name == "action":
            return self.action
        # Unreachable: the caller guards against CTX_NAMES before calling.
        raise VmError(f"ctx name {name!r} is not in CTX_NAMES")


def check_compiler_version(version: str) -> None:
    """Raise unless `version` is one the VM will execute.

    Callers should reject a bundle up front rather than relying on the
    interpreter to bail, exactly as `vm.rs` advises.
    """
    if version not in SUPPORTED_COMPILER_VERSIONS:
        raise VmError(f"unsupported compiler version: {version}")


# ─── Typed stack values ────────────────────────────────────────────────────
# Rust's `Val` is a three-variant enum and `Eq` compares variants, so
# `Bool(true) == I64(1)` is FALSE. Python's `1 == True` is True, so the type
# tag has to be carried explicitly or the mirror diverges on exactly the
# comparison a policy turns on.

_BOOL, _I64, _STR = "b", "i", "s"


class _Vm:
    def __init__(self, bytecode: bytes, budget: int) -> None:
        self.bc = bytecode
        self.budget = budget
        self.pc = 0
        self.stack: list[tuple[str, object]] = []

    # byte readers, mirroring vm.rs read_u8/read_u16/read_i32/read_i64/read_bytes
    def _u8(self, off: int) -> int:
        if self.pc >= len(self.bc):
            raise _malformed(off, "truncated u8 operand")
        v = self.bc[self.pc]
        self.pc += 1
        return v

    def _u16(self, off: int) -> int:
        if len(self.bc) < self.pc + 2:
            raise _malformed(off, "truncated u16 operand")
        v = int.from_bytes(self.bc[self.pc : self.pc + 2], "little", signed=False)
        self.pc += 2
        return v

    def _i32(self, off: int) -> int:
        if len(self.bc) < self.pc + 4:
            raise _malformed(off, "truncated i32 operand")
        v = int.from_bytes(self.bc[self.pc : self.pc + 4], "little", signed=True)
        self.pc += 4
        return v

    def _i64(self, off: int) -> int:
        if len(self.bc) < self.pc + 8:
            raise _malformed(off, "truncated i64 operand")
        v = int.from_bytes(self.bc[self.pc : self.pc + 8], "little", signed=True)
        self.pc += 8
        return v

    def _bytes(self, n: int, off: int) -> bytes:
        if len(self.bc) < self.pc + n:
            raise _malformed(off, "truncated bytes operand")
        v = self.bc[self.pc : self.pc + n]
        self.pc += n
        return v

    def _pop(self, off: int) -> tuple[str, object]:
        if not self.stack:
            raise VmError(f"stack underflow at offset {off}")
        return self.stack.pop()

    def _push(self, val: tuple[str, object]) -> None:
        if len(self.stack) >= MAX_STACK_DEPTH:
            raise VmError(f"stack overflow (max depth {MAX_STACK_DEPTH})")
        self.stack.append(val)

    def _pop_bool(self, off: int) -> bool:
        tag, v = self._pop(off)
        if tag != _BOOL:
            raise _type_mismatch(off, "expected bool")
        return bool(v)

    def _pop_str(self, off: int) -> str:
        tag, v = self._pop(off)
        if tag != _STR:
            raise _type_mismatch(off, "expected string")
        return str(v)


def run(
    bytecode: bytes,
    ctx: EvalContext,
    *,
    instruction_budget: int = DEFAULT_INSTRUCTION_BUDGET,
) -> Verdict:
    """Execute `bytecode` against `ctx` and return one of the four verdicts.

    Raises `VmError` for anything else: an unknown opcode, a malformed operand,
    a type mismatch, a stack or budget limit, or bytecode that runs off the end
    without a terminating verdict.

    **Running off the end raises rather than returning Allow.** That is the one
    behaviour in this file worth reading twice: an implicit Allow on truncated
    bytecode would turn a corrupted bundle into a grant.
    """
    vm = _Vm(bytecode, instruction_budget)
    instructions = 0

    while vm.pc < len(vm.bc):
        instructions += 1
        if instructions > vm.budget:
            raise VmError("instruction budget exceeded")

        op_off = vm.pc
        op = vm.bc[vm.pc]
        if op not in _KNOWN_OPS:
            raise _unknown_opcode(op, op_off)
        vm.pc += 1

        if op == OP_PUSH_BOOL:
            vm._push((_BOOL, vm._u8(op_off) != 0))
        elif op == OP_PUSH_I64:
            vm._push((_I64, vm._i64(op_off)))
        elif op == OP_PUSH_STRING:
            n = vm._u16(op_off)
            if n > MAX_VALUE_SIZE_BYTES:
                raise VmError("string longer than MAX_VALUE_SIZE_BYTES")
            raw = vm._bytes(n, op_off)
            try:
                # The length prefix is BYTES, not characters — one of the
                # committed escaping vectors exists to pin exactly that.
                vm._push((_STR, raw.decode("utf-8")))
            except UnicodeDecodeError as exc:
                raise _malformed(op_off, str(exc)) from exc
        elif op == OP_LOAD_CTX:
            idx = vm._u16(op_off)
            if idx >= len(CTX_NAMES):
                raise VmError(f"ctx index {idx} out of range (max {len(CTX_NAMES)})")
            vm._push((_STR, ctx.load(CTX_NAMES[idx])))
        elif op == OP_EQ:
            b = vm._pop(op_off)
            a = vm._pop(op_off)
            # Tag-then-value, so a bool never equals an integer.
            vm._push((_BOOL, a == b))
        elif op in (OP_LT, OP_GT, OP_LE, OP_GE):
            tb, vb = vm._pop(op_off)
            ta, va = vm._pop(op_off)
            if ta != _I64 or tb != _I64:
                raise _type_mismatch(op_off, "comparison needs two i64")
            a, b = int(va), int(vb)  # type: ignore[arg-type]
            res = {
                OP_LT: a < b,
                OP_GT: a > b,
                OP_LE: a <= b,
                OP_GE: a >= b,
            }[op]
            vm._push((_BOOL, res))
        elif op == OP_AND:
            b = vm._pop_bool(op_off)
            a = vm._pop_bool(op_off)
            # Both operands are already on the stack, so this is not
            # short-circuiting and must not be written as if it were.
            vm._push((_BOOL, a and b))
        elif op == OP_OR:
            b = vm._pop_bool(op_off)
            a = vm._pop_bool(op_off)
            vm._push((_BOOL, a or b))
        elif op == OP_NOT:
            vm._push((_BOOL, not vm._pop_bool(op_off)))
        elif op == OP_JUMP_IF_FALSE:
            # Operand is read BEFORE the condition is popped, matching vm.rs:
            # the relative offset is measured from the pc AFTER the operand.
            rel = vm._i32(op_off)
            if not vm._pop_bool(op_off):
                new_pc = vm.pc + rel
                if not (0 <= new_pc <= len(vm.bc)):
                    raise _malformed(op_off, f"JumpIfFalse to {new_pc} out of range")
                vm.pc = new_pc
        elif op == OP_JUMP:
            rel = vm._i32(op_off)
            new_pc = vm.pc + rel
            if not (0 <= new_pc <= len(vm.bc)):
                raise _malformed(op_off, f"Jump to {new_pc} out of range")
            vm.pc = new_pc
        elif op == OP_ALLOW:
            return Allow()
        elif op == OP_DENY:
            return Deny(vm._pop_str(op_off))
        elif op == OP_ESCALATE:
            return Escalate(vm._pop_str(op_off))
        elif op == OP_CONSTRAIN:
            k = vm._u8(op_off)
            conds = [vm._pop_str(op_off) for _ in range(k)]
            conds.reverse()
            return Constrain(tuple(conds))

    raise _malformed(vm.pc, "bytecode ended without Allow/Deny/Constrain/Escalate")


# ─── Canonical verdict rendering, for vector comparison ───────────────────


def _rust_debug_string(s: str) -> str:
    """Render `s` the way Rust's `{:?}` renders a `String`.

    Needed because the golden vectors record verdicts as `Deny({r:?})`. Rust
    escapes the quote, the backslash and the usual control characters, and
    leaves printable Unicode alone — so an em dash in a refusal reason stays an
    em dash rather than becoming an escape.
    """
    out = ['"']
    for ch in s:
        if ch == '"':
            out.append('\\"')
        elif ch == "\\":
            out.append("\\\\")
        elif ch == "\n":
            out.append("\\n")
        elif ch == "\r":
            out.append("\\r")
        elif ch == "\t":
            out.append("\\t")
        elif ch == "\0":
            out.append("\\0")
        elif ord(ch) < 0x20 or ord(ch) == 0x7F:
            out.append(f"\\u{{{ord(ch):x}}}")
        else:
            out.append(ch)
    out.append('"')
    return "".join(out)


def render_verdict(verdict: Verdict) -> str:
    """The exact string the golden vectors record for a verdict.

    Mirror of `crates/synthera-policyc/tests/golden_vectors.rs`.
    """
    if isinstance(verdict, Allow):
        return "Allow"
    if isinstance(verdict, Deny):
        return f"Deny({_rust_debug_string(verdict.reason)})"
    if isinstance(verdict, Escalate):
        return f"Escalate({_rust_debug_string(verdict.reason)})"
    if isinstance(verdict, Constrain):
        # serde_json's compact Display form, which has no spaces.
        payload = json.dumps(
            {"conditions": list(verdict.conditions)}, separators=(",", ":")
        )
        return f"Constrain({payload})"
    raise TypeError(f"not a verdict: {verdict!r}")


def render_outcome(bytecode: bytes, ctx: EvalContext) -> str:
    """Run and render, mapping a `VmError` to the vectors' `VmError(...)` form.

    This is the single function a conformance test needs, and it is here rather
    than in the test so the rendering cannot be written twice and differ.
    """
    try:
        return render_verdict(run(bytecode, ctx))
    except VmError as exc:
        return f"VmError({exc})"
