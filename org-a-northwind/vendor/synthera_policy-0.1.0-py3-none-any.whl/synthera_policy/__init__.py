"""synthera-policy — Python conformance mirror of the SYNTHERA policy layer.

Two things, both needed by an enforcement point that is not the substrate:

- `vm` — the policy bytecode VM (ADR-0014), locked to the Rust interpreter by
  the committed golden vectors in `conformance/policyc/`.
- `bundle` — bundle integrity verification: the bytecode hash and the Ed25519
  signature over the canonical signing payload.

There is deliberately no evaluator over a bundle's `source` field. The bundle
signature does not cover `source`, so evaluating it would be deciding on bytes
nothing signed. See `vm`'s module docstring.
"""

from synthera_policy.bundle import (
    BundleVerifyError,
    BytecodeHashMismatch,
    InvalidBundleSignature,
    PolicyKeyRegistry,
    UnknownSigningKey,
    UnsupportedSignatureScheme,
    bytecode_digest,
    signing_payload,
    verify_bundle_integrity,
)
from synthera_policy.vm import (
    CTX_NAMES,
    DEFAULT_INSTRUCTION_BUDGET,
    MAX_STACK_DEPTH,
    MAX_VALUE_SIZE_BYTES,
    SUPPORTED_COMPILER_VERSIONS,
    Allow,
    Constrain,
    Deny,
    Escalate,
    EvalContext,
    Verdict,
    VmError,
    check_compiler_version,
    render_outcome,
    render_verdict,
    run,
)

__all__ = [
    "Allow",
    "BundleVerifyError",
    "BytecodeHashMismatch",
    "CTX_NAMES",
    "Constrain",
    "DEFAULT_INSTRUCTION_BUDGET",
    "Deny",
    "Escalate",
    "EvalContext",
    "InvalidBundleSignature",
    "MAX_STACK_DEPTH",
    "MAX_VALUE_SIZE_BYTES",
    "PolicyKeyRegistry",
    "SUPPORTED_COMPILER_VERSIONS",
    "UnknownSigningKey",
    "UnsupportedSignatureScheme",
    "Verdict",
    "VmError",
    "bytecode_digest",
    "check_compiler_version",
    "render_outcome",
    "render_verdict",
    "run",
    "signing_payload",
    "verify_bundle_integrity",
]

__version__ = "0.1.0"
