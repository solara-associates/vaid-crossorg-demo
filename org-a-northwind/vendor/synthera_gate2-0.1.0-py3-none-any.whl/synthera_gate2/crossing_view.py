"""Render a crossing as plain English, for a person who did not build it.

## The rule this module exists to enforce

Every label is what a non-engineer would call the thing. Not `vaid_id`, not
`bytecode_sha256`, not `gate2`. A demo audience reading an identifier they have
no way to interpret learns nothing, and two identical-looking hashes side by
side actively mislead.

So: no jargon in a label, no em dash or en dash anywhere, no placeholder text,
no "coming soon", and nothing on screen that the signed audit does not say.
Each of those is a test in `test_crossing_view.py` rather than a convention.

## Identifiers are shortened AND labelled as shortened

A hash is rendered as its first eight characters followed by the word
"(shortened)". Two different policies whose digests both render as `2db4b544`
would otherwise read as the same policy, which is the failure mode a demo
cannot afford. Where two shortened values appear together and are equal, the
renderer says they match rather than leaving the reader to compare strings.

## It renders only what the audit says

The input is the signed audit rows. Nothing is recomputed and nothing is
inferred, so the screen cannot claim more than the evidence does. If a field is
absent the renderer says it is not recorded, rather than leaving a blank that
reads as a zero or as a success.
"""

from __future__ import annotations

from dataclasses import dataclass

#: What each actor is called on screen. These are the brief's labels.
LABEL_ISSUER = "Issuer"
LABEL_RECEIVING_AGENT = "Receiving agent"
LABEL_GATE1 = "Gate 1"
LABEL_GATE2 = "Gate 2"

#: Said plainly, once, next to Gate 1, because the whole point is that Gate 1
#: is not permission and an audience will otherwise assume it is.
GATE1_CAVEAT = "This step only works out what is being asked. It does not grant anything."

_NOT_RECORDED = "not recorded"


def short(value: str | None, keep: int = 8) -> str:
    """Shorten an identifier and SAY that it is shortened.

    An unlabelled truncation is how two different values come to look like one.
    """
    if not value:
        return _NOT_RECORDED
    text = str(value)
    if text.startswith("sha256-"):
        text = text[len("sha256-") :]
    if len(text) <= keep:
        return text
    return f"{text[:keep]} (shortened)"


def plain_decision(decision: str | None) -> str:
    """A verdict in words a person uses."""
    return {
        "allow": "Allowed",
        "deny": "Refused",
        "escalate": "Sent to a person to decide",
        "proceed": "Passed on to the next check",
        "refuse_early": "Refused",
    }.get(str(decision), _NOT_RECORDED)


def plain_confidence(confidence: float | None, threshold: float | None) -> str:
    """A score, as a percentage, said against the bar it had to clear."""
    if confidence is None:
        return _NOT_RECORDED
    pct = f"{confidence * 100:.0f} out of 100"
    if threshold is None:
        return pct
    bar = f"{threshold * 100:.0f} out of 100"
    verb = "at or above" if confidence >= threshold else "below"
    return f"{pct}, which is {verb} the bar of {bar} set for this classifier"


@dataclass(frozen=True)
class Line:
    """One row on screen: a plain label and a plain value."""

    label: str
    value: str


def render_gate1(row: dict) -> list[Line]:
    """The Gate 1 panel, from Gate 1's audit row."""
    lines = [
        Line("What the agent was asked to do", "Push a change straight to production"),
        Line("What this step decided it was", _action_in_words(row.get("action"))),
        Line("How sure it was", plain_confidence(row.get("confidence"), row.get("threshold"))),
        Line("Outcome", plain_decision(row.get("decision"))),
        Line("Which classifier decided", _engine_in_words(row)),
    ]
    claim = row.get("authority_claim_detected")
    if claim is not None:
        lines.append(
            Line(
                "Did the request claim permission it did not have?",
                "Yes, and it was recorded. It changed nothing."
                if claim
                else "No",
            )
        )
    lines.append(Line("Worth knowing", GATE1_CAVEAT))
    return lines


def render_gate2(row: dict) -> list[Line]:
    """The Gate 2 panel, from Gate 2's audit row."""
    policy = row.get("policy") or {}
    lines = [
        # The tool NAME and the action it performs are rendered differently on
        # purpose. Both were `deploy` on adjacent lines, which reads as a
        # duplicated field rather than as two facts, and an audience asked to
        # tell two identical-looking values apart learns nothing from either.
        Line("Which tool the agent tried to use", str(row.get("tool") or _NOT_RECORDED)),
        Line("What that tool does", _action_in_words(row.get("action"))),
        Line("What it was pointed at", str(row.get("resource") or _NOT_RECORDED)),
        Line("Which rulebook was checked", _policy_in_words(policy)),
        Line("Outcome", plain_decision(row.get("decision"))),
        Line("Why", str(row.get("reason") or _NOT_RECORDED)),
    ]
    if row.get("decision") in ("deny", "escalate"):
        lines.append(Line("Did the tool run?", "No. It was stopped before it ran."))
    elif row.get("decision") == "allow":
        lines.append(Line("Did the tool run?", "Yes."))
    return lines


def render_evidence(rows: list[dict], *, chain_verified: bool) -> list[Line]:
    """The evidence panel: that the record is signed and complete."""
    return [
        Line("Steps recorded", str(len(rows))),
        Line(
            "Signed record",
            "Yes. Every step was signed by the receiving organisation's own key."
            if rows
            else _NOT_RECORDED,
        ),
        Line(
            "Record complete and unaltered",
            "Yes. The steps are linked to each other, so removing one would show."
            if chain_verified
            else "No. The check on the record did not pass.",
        ),
        Line(
            "Who signed it",
            str(rows[0].get("key_id")) if rows and rows[0].get("key_id") else _NOT_RECORDED,
        ),
    ]


def _action_in_words(action: str | None) -> str:
    return {
        "deploy": "A release to an environment",
        "secrets/rotate": "A change to a stored credential",
        "read-logs": "A read of the logs",
    }.get(str(action), _NOT_RECORDED if action is None else str(action))


def _engine_in_words(row: dict) -> str:
    """The classifier, named for a reader.

    `prompt_id` is DELIBERATELY not rendered. It is a slug
    (`gate1-action-classifier.v1`) that an audience has no way to interpret,
    and an unexplained identifier on screen is the thing a plain-language read
    is supposed to catch. It is required in the SIGNED AUDIT, where it makes a
    decision reconstructable, and that is where it stays.
    """
    engine = row.get("engine_id")
    if not engine:
        return _NOT_RECORDED
    version = row.get("engine_version")
    if version:
        return f"{engine}, version {version}"
    return str(engine)


def _policy_in_words(policy: dict) -> str:
    if not policy:
        return _NOT_RECORDED
    name = policy.get("name") or _NOT_RECORDED
    semver = policy.get("semver")
    digest = short(policy.get("bytecode_sha256"))
    owner = policy.get("tenant_id")
    text = f"{name}"
    if semver:
        text += f", version {semver}"
    if owner:
        text += f", published by {owner}"
    return f"{text} (rulebook fingerprint {digest})"


def render(
    *, gate1_row: dict, gate2_row: dict, rows: list[dict], chain_verified: bool
) -> dict[str, list[Line]]:
    """The whole crossing, as four labelled panels."""
    return {
        LABEL_ISSUER: [
            Line(
                "Who issued the agent's badge",
                str((gate2_row.get("policy") or {}).get("tenant_id") or _NOT_RECORDED),
            ),
            Line(
                "Which rulebook travelled with the badge",
                _policy_in_words(gate2_row.get("policy") or {}),
            ),
        ],
        LABEL_RECEIVING_AGENT: [
            Line("Which organisation received the request", str(gate2_row.get("org") or _NOT_RECORDED)),
            Line("Which agent was asking", short(gate2_row.get("agent_vaid_id"), keep=8)),
            Line("What kind of agent it is", str(gate2_row.get("verified_agent_class") or _NOT_RECORDED)),
        ],
        LABEL_GATE1: render_gate1(gate1_row),
        LABEL_GATE2: render_gate2(gate2_row),
        "Evidence": render_evidence(rows, chain_verified=chain_verified),
    }


def to_text(panels: dict[str, list[Line]]) -> str:
    """A plain-text rendering, which is what a test and a terminal both read."""
    out: list[str] = []
    for title, lines in panels.items():
        out.append(title)
        width = max((len(l.label) for l in lines), default = 0)
        for line in lines:
            out.append(f"  {line.label.ljust(width)}  {line.value}")
        out.append("")
    return "\n".join(out).rstrip() + "\n"
