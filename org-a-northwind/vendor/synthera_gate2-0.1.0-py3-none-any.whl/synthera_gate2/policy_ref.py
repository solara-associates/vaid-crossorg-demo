"""The policy reference a badge carries, and how it is read back.

## Why it rides in `capability_set`

A VAID document's field set is closed (`vaid_mint.document.build_unsigned_vaid_document`
assembles a fixed set), so a new member needs a producer-side change in
vaid-mint. `capability_set` is already `list[str]` on both the seed and the
document, it is already chosen by the issuer, and capabilities attenuate by
SUBSET, so a delegated child carrying the same string is attenuating correctly
rather than escalating. Encoding the reference as one opaque capability
therefore needs no library change and breaks no existing verifier: one that
does not know the prefix treats it as an ordinary capability string.

## Why it is provenance and not a constraint

The reference says WHICH policy document the issuer derived this badge's
authority from. It narrows nothing by itself: the enforced envelope is still
`scope_boundary`, and the policy decides the action. That is what makes a
capability string (ignored by an old verifier) the right carrier rather than a
new scope kind (refused by an old verifier). A reference that ever starts
carrying constraint has to move to a scope kind, so that an old verifier fails
CLOSED on it instead of ignoring it.

## The hash is the bytecode hash, deliberately

`bytecode_sha256` is the digest of `compiled_bytecode`, and it is the one field
of the bundle that the bundle signature covers transitively. The bundle's
`source` is covered by neither the hash nor the signature, so a reference to
`source` would name a moving target. Pinning the bytecode hash is what makes
the reference mean "this exact program", and it is why the gate can refuse a
mirror that serves a different bundle under the same name and version.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

#: The prefix that marks a capability string as a policy reference.
POLICY_CAPABILITY_PREFIX = "policy:"

# tenant/name@semver#sha256-<64 hex>
#
# Anchored at both ends and with no optional groups: a reference is either
# completely well formed or it is not a reference. A partial match would let a
# truncated hash through, and the hash is the whole point.
_REF_RE = re.compile(
    r"^policy:"
    r"(?P<tenant_id>[A-Za-z0-9][A-Za-z0-9._-]*)"
    r"/"
    r"(?P<name>[A-Za-z0-9][A-Za-z0-9._-]*)"
    r"@"
    r"(?P<semver>\d+\.\d+\.\d+)"
    r"#sha256-"
    r"(?P<bytecode_sha256>[0-9a-f]{64})"
    # `\Z`, not `$`: Python's `$` also matches just before a trailing newline,
    # so `$` would have accepted "policy:...#sha256-<hash>\n". A security parser
    # should not quietly tolerate trailing whitespace.
    r"\Z"
)


class PolicyRefError(Exception):
    """A capability string claimed to be a policy reference and was not usable."""


class NoPolicyReference(PolicyRefError):
    def __init__(self) -> None:
        super().__init__(
            "the badge names no policy. A badge that names no policy gets no "
            "tool call."
        )


class MalformedPolicyReference(PolicyRefError):
    def __init__(self, raw: str) -> None:
        # The offending string is echoed because an issuer debugging a mint
        # needs to see what it actually emitted. It is a public capability
        # string on a presented badge, not a secret.
        super().__init__(f"malformed policy reference: {raw!r}")


class AmbiguousPolicyReference(PolicyRefError):
    def __init__(self, count: int) -> None:
        super().__init__(
            f"the badge carries {count} policy references. Exactly one policy "
            "decides a tool call, so a badge naming several is refused rather "
            "than one of them being picked."
        )


@dataclass(frozen=True)
class PolicyRef:
    """The four fields that identify a policy version.

    Deliberately the same quadruple as `BundleActivationReceipt`
    (`tenant_id`, `bundle_name`, `semver`, `bytecode_sha256`), so what the
    issuer published and what the badge names are the same identity rather than
    two things that have to be kept in step.
    """

    tenant_id: str
    name: str
    semver: str
    bytecode_sha256: str

    def to_capability(self) -> str:
        return (
            f"{POLICY_CAPABILITY_PREFIX}{self.tenant_id}/{self.name}"
            f"@{self.semver}#sha256-{self.bytecode_sha256}"
        )

    @property
    def activation_key(self) -> tuple[str, str, str]:
        """The key a mirror is looked up by. Note the hash is NOT part of it:
        the lookup finds a bundle by name and version, and the hash is then
        CHECKED against what came back. Including the hash in the key would
        turn a tampered bundle into a cache miss, which reads as "not found"
        rather than as "the bytes are not the ones the issuer signed".
        """
        return (self.tenant_id, self.name, self.semver)


def build_capability(
    *, tenant_id: str, name: str, semver: str, bytecode_sha256: str
) -> str:
    """Build the capability string an issuer puts in `capability_set`.

    Round-trips through `parse_capability`, which is asserted by a test, so an
    issuer cannot mint a reference the gate will refuse to read.
    """
    ref = PolicyRef(
        tenant_id=tenant_id,
        name=name,
        semver=semver,
        bytecode_sha256=bytecode_sha256.lower(),
    )
    # Validate on the way out, not only on the way in: a malformed reference
    # minted into a signed badge cannot be fixed without re-minting.
    parse_capability(ref.to_capability())
    return ref.to_capability()


def parse_capability(capability: str) -> PolicyRef:
    """Parse one capability string into a `PolicyRef`, or raise."""
    match = _REF_RE.match(capability)
    if match is None:
        raise MalformedPolicyReference(capability)
    return PolicyRef(**match.groupdict())


def is_policy_capability(capability: str) -> bool:
    return capability.startswith(POLICY_CAPABILITY_PREFIX)


def policy_ref_from_badge(leaf: dict) -> PolicyRef:
    """Read THE policy reference off a presented VAID document.

    Fails closed in three directions, each its own refusal:

    - no reference at all, so nothing names a policy;
    - more than one, so which policy decides would be a choice the gate makes
      rather than one the issuer signed;
    - one that is present but malformed, which is never treated as absent.

    The last of those matters most: silently ignoring an unparseable reference
    would turn a typo in an issuer's mint into "this badge names no policy",
    and from there into whatever the no-reference path does.
    """
    capabilities = leaf.get("capability_set") or []
    if not isinstance(capabilities, list):
        raise MalformedPolicyReference(repr(capabilities))

    candidates = [
        c for c in capabilities if isinstance(c, str) and is_policy_capability(c)
    ]
    if not candidates:
        raise NoPolicyReference()
    if len(candidates) > 1:
        raise AmbiguousPolicyReference(len(candidates))
    return parse_capability(candidates[0])
