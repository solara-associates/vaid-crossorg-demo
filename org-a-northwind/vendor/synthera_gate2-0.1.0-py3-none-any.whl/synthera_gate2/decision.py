"""Gate 2: the decision a tool call has to pass before it runs.

Every path through this module that is not an explicit allow is a refusal.
There is no branch that returns `allow` on an absent answer, and that is the
property the tests are organised around.

## The order, and what each step is for

1. The badge's ISSUER signature, expiry, revocation, depth and attenuation are
   the receiver's existing checks and are an INPUT here (`BadgeVerification`).
   This module refuses unless they passed. It does not re-implement them: the
   receiver already has a keystore and a revocation client, and a second
   implementation of a check is a second thing that can disagree.
2. Proof of possession, so the presenter holds the badge's key rather than
   merely the badge's bytes.
3. The policy reference off the badge. No reference, no tool call.
4. The bundle from a mirror. Not found is a refusal, not a fallback.
5. The bundle's bytecode hash against the hash THE BADGE NAMES. This is the
   check that makes the reference mean something: without it the mirror decides
   which program runs.
6. The bundle's signature, by a key resolved from the policy key registry.
7. The compiler version, before execution rather than during it.
8. The bytecode, over the tool call's own action and resource.
9. The audit write. A failure here REFUSES the call.

## Step 9 is a deliberate departure from the demo's behaviour

The cross-org demo lets an audit write fail without blocking the response, and
comments it as a reasonable call for a demo. For an enforcement gate it is the
wrong default: a gate that performs an action it could not record has produced
the action and no evidence. For a control whose output IS evidence, the
evidence write is part of the control.

## What goes into the VM's context, and what must not

`resource` and `action` are taken from the TOOL CALL, never from anything the
model wrote in prose: the prose is what Gate 1 reads, and a policy decided on
prose would be decided on attacker-controlled text.

`agent_class` is taken from the VERIFIED badge document. Note this is stronger
than the substrate's own bytecode path, which builds it from a caller-supplied
key (`synthera-policy/src/engine.rs:436`) and is the documented reason the
policy language refuses `agent_class` as a condition name. Here the value comes
from a document whose issuer signature and proof of possession have both just
been checked, so index 0 of the context table is sound at this gate even though
it is not at that one.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Callable, Literal, Protocol

from synthera_policy import (
    Allow,
    BundleVerifyError,
    Constrain,
    Deny,
    Escalate,
    EvalContext,
    PolicyKeyRegistry,
    VmError,
    bytecode_digest,
    check_compiler_version,
    run,
    verify_bundle_integrity,
)

from synthera_gate2.policy_ref import PolicyRef, PolicyRefError, policy_ref_from_badge
from synthera_gate2.pop import NonceStorePort, PopError, verify_proof_of_possession

Outcome = Literal["allow", "deny", "escalate"]


@dataclass(frozen=True)
class ToolCall:
    """What the agent proposed. `action` and `resource` are what policy reads."""

    tool: str
    action: str
    resource: str


@dataclass(frozen=True)
class BadgeVerification:
    """The receiver's own badge checks, as already performed.

    `verified` defaults to False so a caller that forgets to set it refuses.
    The default on a security input is the safe answer, not the convenient one.
    """

    verified: bool = False
    failure_reason: str | None = None


@dataclass(frozen=True)
class Gate2Decision:
    outcome: Outcome
    reason: str
    policy: dict | None = None
    constraints: tuple[str, ...] = ()
    #: Which step refused, for the audit and for the crossing view. Named rather
    #: than inferred from the reason text, because a reader should not have to
    #: parse prose to know which control fired.
    refused_at: str | None = None

    @property
    def tool_may_run(self) -> bool:
        return self.outcome == "allow"


class BundleMirrorPort(Protocol):
    """Resolves `(tenant_id, name, semver)` to a `PolicyBundleV1` wire dict.

    Returns None when the bundle is absent. The mirror is NOT trusted: every
    byte it serves is checked against the badge's hash and the issuer's
    signature, so a compromised mirror can withhold a bundle but cannot forge
    one. Withholding is handled by refusing.
    """

    def fetch(self, tenant_id: str, name: str, semver: str) -> dict | None: ...


@dataclass
class InMemoryBundleMirror:
    bundles: dict[tuple[str, str, str], dict] = field(default_factory=dict)

    def put(self, bundle: dict) -> None:
        self.bundles[
            (bundle["tenant_id"], bundle["name"], bundle["semver"])
        ] = bundle

    def fetch(self, tenant_id: str, name: str, semver: str) -> dict | None:
        return self.bundles.get((tenant_id, name, semver))


def _policy_fields(ref: PolicyRef, bundle: dict | None) -> dict:
    """What the audit records about the policy. Only fields the signature
    covers, plus the key reference needed to re-check it later."""
    out = {
        "tenant_id": ref.tenant_id,
        "name": ref.name,
        "semver": ref.semver,
        "bytecode_sha256": ref.bytecode_sha256,
    }
    if bundle is not None:
        out["signing_key_ref"] = bundle.get("signing_key_ref")
    return out


def decide(
    *,
    tool_call: ToolCall,
    leaf: dict,
    badge: BadgeVerification,
    headers: dict,
    method: str,
    path: str,
    body: bytes,
    mirror: BundleMirrorPort,
    policy_keys: PolicyKeyRegistry,
    nonce_store: NonceStorePort,
    now: datetime | None = None,
) -> Gate2Decision:
    """Reach a verdict for one proposed tool call. Never raises.

    Returns a decision in every case, including every failure, because the
    caller has to audit the refusal as well as the allow. An exception escaping
    here would be a tool call with no recorded decision.
    """
    # 1. The receiver's own badge checks.
    if not badge.verified:
        return Gate2Decision(
            outcome="deny",
            reason=badge.failure_reason
            or "the badge did not pass the receiver's own verification.",
            refused_at="badge_verification",
        )

    # 2. Proof of possession.
    try:
        verify_proof_of_possession(
            leaf=leaf,
            headers=headers,
            method=method,
            path=path,
            body=body,
            nonce_store=nonce_store,
            now=now,
        )
    except PopError as exc:
        return Gate2Decision(
            outcome="deny", reason=str(exc), refused_at="proof_of_possession"
        )

    # 3. The policy reference.
    try:
        ref = policy_ref_from_badge(leaf)
    except PolicyRefError as exc:
        return Gate2Decision(
            outcome="deny", reason=str(exc), refused_at="policy_reference"
        )

    # 4. The bundle.
    try:
        bundle = mirror.fetch(*ref.activation_key)
    except Exception as exc:  # noqa: BLE001 - a mirror failure must refuse
        return Gate2Decision(
            outcome="deny",
            reason=(
                "the policy mirror could not be read, so the policy this badge "
                f"names could not be loaded: {exc}"
            ),
            policy=_policy_fields(ref, None),
            refused_at="bundle_fetch",
        )
    if bundle is None:
        return Gate2Decision(
            outcome="deny",
            reason=(
                f"the policy this badge names ({ref.name} version {ref.semver}) "
                "is not in the mirror, so there is nothing to check this call against."
            ),
            policy=_policy_fields(ref, None),
            refused_at="bundle_fetch",
        )

    policy = _policy_fields(ref, bundle)

    # 5. The hash the BADGE names, against the bundle that came back.
    #
    # Before the signature, deliberately. A bundle that is validly signed but
    # is not the program the badge names is a different failure from a bundle
    # that is not signed at all, and the audit should say which.
    compiled = bytes(bundle.get("compiled_bytecode") or b"")
    actual = bytecode_digest(compiled)
    if actual != ref.bytecode_sha256:
        return Gate2Decision(
            outcome="deny",
            reason=(
                "the policy in the mirror is not the one this badge names: the "
                f"badge names program {ref.bytecode_sha256[:12]} and the mirror "
                f"served {actual[:12]}."
            ),
            policy=policy,
            refused_at="bytecode_hash",
        )

    # 6. The bundle's own signature.
    try:
        verify_bundle_integrity(bundle, policy_keys)
    except BundleVerifyError as exc:
        return Gate2Decision(
            outcome="deny",
            reason=f"the policy document did not verify: {exc}",
            policy=policy,
            refused_at="bundle_signature",
        )

    # 7. The compiler version, up front rather than mid-execution.
    try:
        check_compiler_version(str(bundle.get("compiler_version", "")))
    except VmError as exc:
        return Gate2Decision(
            outcome="deny",
            reason=f"the policy cannot be evaluated here: {exc}",
            policy=policy,
            refused_at="compiler_version",
        )

    # 8. Evaluate. `resource` and `action` come from the tool call; the agent
    #    class comes from the verified document.
    ctx = EvalContext(
        agent_class=str(leaf.get("agent_class", "")),
        tenant_id=str(leaf.get("tenant_id", "")),
        resource=tool_call.resource,
        action=tool_call.action,
    )
    try:
        verdict = run(compiled, ctx)
    except VmError as exc:
        # An engine error is a refusal here, not an escalation. The substrate
        # maps a VmError to Escalate because it is deciding whether to continue
        # a request; this gate is deciding whether to RUN A TOOL, and a tool
        # must not run on a verdict that was never reached.
        return Gate2Decision(
            outcome="deny",
            reason=f"the policy could not be evaluated, so the call is refused: {exc}",
            policy=policy,
            refused_at="policy_evaluation",
        )

    if isinstance(verdict, Allow):
        return Gate2Decision(outcome="allow", reason="allowed by policy.", policy=policy)
    if isinstance(verdict, Deny):
        return Gate2Decision(
            outcome="deny",
            reason=verdict.reason,
            policy=policy,
            refused_at="policy_rule",
        )
    if isinstance(verdict, Escalate):
        return Gate2Decision(
            outcome="escalate",
            reason=verdict.reason,
            policy=policy,
            refused_at="policy_rule",
        )
    if isinstance(verdict, Constrain):
        return Gate2Decision(
            outcome="allow",
            reason="allowed by policy, with constraints.",
            policy=policy,
            constraints=verdict.conditions,
        )

    # Unreachable: `run` returns one of four verdicts or raises. Written as a
    # refusal anyway, because an unreachable branch that returns a grant is one
    # refactor away from being reachable.
    return Gate2Decision(
        outcome="deny",
        reason="the policy returned a verdict this gate does not understand.",
        policy=policy,
        refused_at="policy_evaluation",
    )


def run_tool_call(
    *,
    decision: Gate2Decision,
    tool: Callable[[], object],
    write_audit: Callable[[Gate2Decision], None],
) -> object:
    """Audit first, then run. The ordering IS the control.

    Raises if the audit write fails, and the tool is not called. A gate that
    performed an action it could not record would have produced the action and
    no evidence of it.
    """
    write_audit(decision)
    if not decision.tool_may_run:
        raise PermissionError(decision.reason)
    return tool()
