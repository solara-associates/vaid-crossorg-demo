"""Per-request proof-of-possession: the check that stops a badge being a bearer token.

## The gap this closes

Verifying the ISSUER's signature over a badge document proves the badge is
authentic. It does not prove the party presenting it holds the badge's key. The
cross-org demo verifies only the former, so as it stands a presented badge is a
BEARER credential and whoever holds the bytes can present it.

`vaid-pop` already ships the signer, byte-locked to the Rust client by a shared
vector, and the receiver's deploy already copies `vaid_pop` into its bundle and
never imports it. So this is wiring, not new cryptography.

## The four checks, in this order, and why the order is the security property

1. **Present.** All four PoP headers, or refuse. An absent proof is not a weak
   proof, it is no proof.
2. **Fresh.** Within a bounded window, so a captured proof expires.
3. **Unused.** The nonce is claimed BEFORE the signature is checked, so two
   concurrent replays cannot both pass by racing between the check and the
   claim. `vaid-mint` does it in this order at mint time for the same reason.
4. **Signed by the badge's own key.** `public_key_der` from the verified badge
   document, never a key supplied alongside the request, or the presenter would
   be choosing the key that authenticates it.

## Why the nonce store is a port, and why its failure refuses

Replay protection is durable shared state at the enforcement point (A5.10): it
has to be declared, and a read that cannot be completed must REFUSE rather than
assume the nonce is fresh. A store that fails open turns an outage into an open
replay window, which is worse than an outage.
"""

from __future__ import annotations

import base64
import hashlib
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Protocol

from vaid_pop import (
    HEADER_NONCE,
    HEADER_SIGNATURE,
    HEADER_TIMESTAMP,
    build_request_auth_payload,
    verify_signed_payload,
)

#: Matches `vaid-mint`'s mint-time PoP window, so a client that can mint can
#: also call: a receiver stricter than the issuer would reject proofs the
#: issuer considers fresh, for no stated reason.
DEFAULT_FRESHNESS_SECONDS = 300


class PopError(Exception):
    """Proof-of-possession was not established. Always a refusal."""


class PopMissing(PopError):
    def __init__(self, what: str) -> None:
        super().__init__(
            f"no proof of possession: {what}. Without it the badge is a bearer "
            "credential and holding the bytes would be enough to use it."
        )


class PopStale(PopError):
    def __init__(self, skew_seconds: float, window: int) -> None:
        super().__init__(
            f"proof of possession is outside the {window}s freshness window "
            f"(off by {skew_seconds:.0f}s), so a captured proof cannot be replayed later."
        )


class PopReplayed(PopError):
    def __init__(self, nonce_digest: str) -> None:
        # The nonce DIGEST, not the nonce. The nonce is single-use and logging
        # it is harmless today, but a digest is sufficient to correlate
        # attempts and keeps a request-authenticating value out of the log.
        super().__init__(
            f"proof of possession reuses a nonce already seen (digest {nonce_digest})."
        )


class PopStoreUnavailable(PopError):
    def __init__(self) -> None:
        super().__init__(
            "the replay-protection store could not be reached, so this request "
            "cannot be shown to be fresh. Refusing: a store that fails open "
            "turns an outage into an open replay window."
        )


class PopBadSignature(PopError):
    def __init__(self) -> None:
        super().__init__(
            "proof of possession does not verify against the badge's own public "
            "key, so the presenter does not hold the key this badge names."
        )


class NonceStorePort(Protocol):
    """Single-use nonce claims.

    `claim` returns True exactly once per nonce and False for a nonce already
    seen. It must raise on any failure to reach its backing store: returning
    True on an error is an open replay window, and returning False would be a
    denial of service that looks like an attack.
    """

    def claim(self, nonce: str) -> bool: ...


@dataclass
class InMemoryNonceStore:
    """For tests and for a single-process deployment.

    NOT a deployment default: a receiver with more than one instance needs a
    shared store, or each instance holds its own idea of what has been used and
    a replay succeeds by landing on a different instance. That is the reason
    this class is named for what it is.
    """

    seen: set[str] | None = None

    def __post_init__(self) -> None:
        if self.seen is None:
            self.seen = set()

    def claim(self, nonce: str) -> bool:
        assert self.seen is not None
        if nonce in self.seen:
            return False
        self.seen.add(nonce)
        return True


def _nonce_digest(nonce: str) -> str:
    return hashlib.sha256(nonce.encode("utf-8")).hexdigest()[:16]


def verify_proof_of_possession(
    *,
    leaf: dict,
    headers: dict,
    method: str,
    path: str,
    body: bytes,
    nonce_store: NonceStorePort,
    now: datetime | None = None,
    freshness_seconds: int = DEFAULT_FRESHNESS_SECONDS,
) -> None:
    """Raise a `PopError` unless the presenter holds the badge's private key.

    `leaf` must be a badge whose ISSUER signature has already been verified:
    this function reads `public_key_der` out of it and trusts it, which is only
    sound once the document is known to be authentic. Calling this on an
    unverified document would be checking a signature against a key the
    attacker also supplied.
    """
    # Header lookup is case-insensitive: the wire names are lowercase but
    # gateways routinely re-case headers, and a canonical-case-only lookup
    # would turn a working client into a refusal at the first proxy.
    lower = {str(k).lower(): v for k, v in (headers or {}).items()}
    timestamp = lower.get(HEADER_TIMESTAMP)
    nonce = lower.get(HEADER_NONCE)
    signature_b64 = lower.get(HEADER_SIGNATURE)

    for value, what in (
        (timestamp, f"{HEADER_TIMESTAMP} header is absent"),
        (nonce, f"{HEADER_NONCE} header is absent"),
        (signature_b64, f"{HEADER_SIGNATURE} header is absent"),
    ):
        if not value:
            raise PopMissing(what)

    public_key_der = leaf.get("public_key_der")
    if not public_key_der:
        raise PopMissing("the badge carries no public key to check a proof against")

    # 2. Freshness.
    try:
        signed_at = datetime.strptime(str(timestamp), "%Y-%m-%dT%H:%M:%SZ").replace(
            tzinfo=timezone.utc
        )
    except ValueError as exc:
        raise PopMissing(
            f"{HEADER_TIMESTAMP} is not whole-second RFC 3339 UTC: {timestamp!r}"
        ) from exc
    reference = now or datetime.now(timezone.utc)
    skew = abs((reference - signed_at).total_seconds())
    if skew > freshness_seconds:
        raise PopStale(skew, freshness_seconds)
    # A proof from the future beyond the window is caught by abs() above, which
    # is deliberate: a clock-skewed client is a refusal rather than a licence to
    # pre-sign requests.

    # 3. Single use. Claimed BEFORE the signature check so a replay cannot race.
    try:
        fresh = nonce_store.claim(str(nonce))
    except Exception as exc:  # noqa: BLE001 - any store failure must refuse
        raise PopStoreUnavailable() from exc
    if not fresh:
        raise PopReplayed(_nonce_digest(str(nonce)))

    # 4. Signed by the badge's own key.
    payload = build_request_auth_payload(
        vaid_id=str(leaf.get("vaid_id", "")),
        method=method.upper(),
        path=path,
        body_sha256=hashlib.sha256(body).hexdigest(),
        tenant_id=str(leaf.get("tenant_id", "")),
        timestamp=str(timestamp),
        client_nonce=str(nonce),
    )
    try:
        signature = base64.b64decode(str(signature_b64), validate=True)
    except Exception as exc:  # noqa: BLE001
        raise PopBadSignature() from exc

    if not verify_signed_payload(payload, bytes(public_key_der), signature):
        raise PopBadSignature()
