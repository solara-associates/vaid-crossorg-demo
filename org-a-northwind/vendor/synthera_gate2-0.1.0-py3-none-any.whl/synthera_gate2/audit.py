"""Gate 2's audit record: signed per record, and CHAINED across records.

## What was wrong with signing alone

The cross-org demo's receiver signs each audit record individually with its own
key and has no `prev_hash` and no sequence number. Signing proves each record's
integrity; nothing proves the integrity of the SET. A record can be deleted and
the remaining signatures all still verify, so the one thing an evidence trail
has to resist, selective removal, is exactly what it does not resist.

`seq` plus `prev_hash` over the previous record's signature fixes that: a
removed record leaves a gap in the sequence and a `prev_hash` that matches
nothing.

## What the record can and cannot say about which rule decided

It names the policy by the identity the issuer signed: tenant, name, semver and
bytecode hash. It records the decision and the REASON STRING the policy
produced.

It does NOT name a rule id, and that is a limit of the artefact rather than a
choice. Rule names exist only in the bundle's `source`, which the bundle
signature does not cover, and the compiler discards them when it lowers rules
to bytecode (`synthera-policyc/src/lower.rs` emits rules in source order with
no names). So a rule id in this record could only come from an unsigned side
channel, and writing one would be asserting from unsigned data a fact the
record presents as evidence.

The reason string IS signed, because it is a `PushString` operand inside the
bytecode the signature covers. So "which rule decided this" is answered to
anyone holding the source, by matching the reason, and the record never claims
more than it can prove. `matched_rule` is therefore explicitly null with
`matched_rule_basis` saying why, rather than absent: an absent field is
indistinguishable from a field nobody set.

Making the rule id signed evidence needs the compiler to emit a rule map inside
the hashed artefact. That is a bundle-format change and a `compiler_version`
bump, which ADR-0003 r5 makes a re-publish of every bundle in the estate.
"""

from __future__ import annotations

import base64
import hashlib
import json
from dataclasses import dataclass
from typing import Callable

#: The genesis `prev_hash`. A fixed, recognisable literal rather than an empty
#: string or null, so "this is the first record" is a positive statement and is
#: distinguishable from "prev_hash was never set".
GENESIS_PREV_HASH = "sha256-genesis"

#: Written into every record so a later reader knows which basis the
#: `matched_rule` null stands on, rather than having to reconstruct the reason
#: from a document.
MATCHED_RULE_BASIS = (
    "not derivable from signed bytes: rule names live in the bundle's unsigned "
    "source and are discarded at compile time. The signed reason string "
    "identifies the rule to anyone holding the source."
)


class AuditChainError(Exception):
    """The chain does not hold. Never raised for a single bad signature alone;
    `verify_chain` reports which record and which property failed."""


@dataclass(frozen=True)
class AuditRecord:
    """One Gate 2 decision, as written."""

    body: dict

    @property
    def seq(self) -> int:
        return int(self.body["seq"])

    @property
    def signature_b64(self) -> str:
        return str(self.body["signature_b64"])


def record_signing_bytes(body: dict) -> bytes:
    """The bytes a record's signature covers: the record minus its own
    signature, canonically serialised.

    `sort_keys` plus separators with no spaces is the canonical form, and the
    signature field is excluded by construction rather than by deleting it
    afterwards, because a delete-then-sign that forgot the delete would sign a
    different shape than it verifies.
    """
    unsigned = {k: v for k, v in body.items() if k != "signature_b64"}
    return json.dumps(unsigned, sort_keys=True, separators=(",", ":")).encode("utf-8")


def chain_hash(previous: AuditRecord | None) -> str:
    """The `prev_hash` a record following `previous` must carry.

    Computed over the previous record's SIGNATURE, not over its body: the
    signature already commits to the whole body, so chaining on it makes the
    link depend on the record having been validly signed rather than merely
    having existed.
    """
    if previous is None:
        return GENESIS_PREV_HASH
    digest = hashlib.sha256(previous.signature_b64.encode("utf-8")).hexdigest()
    return f"sha256-{digest}"


def build_record(
    *,
    seq: int,
    previous: AuditRecord | None,
    timestamp_ms: int,
    org: str,
    key_id: str,
    credential_hash: str,
    agent_vaid_id: str | None,
    verified_agent_class: str | None,
    tool: str,
    action: str,
    resource: str,
    decision: str,
    reason: str,
    policy: dict | None,
    gate: str,
    sign: Callable[[bytes], bytes],
    extra: dict | None = None,
) -> AuditRecord:
    """Build and sign one record.

    `sign` is injected rather than a key being passed, so this module never
    holds key material and a caller can back it with a KMS, a Secrets Manager
    key or a test key without this code changing.
    """
    body: dict = {
        "seq": seq,
        "prev_hash": chain_hash(previous),
        "ts": timestamp_ms,
        "org": org,
        "gate": gate,
        "credential_hash": credential_hash,
        "agent_vaid_id": agent_vaid_id,
        "verified_agent_class": verified_agent_class,
        "tool": tool,
        "action": action,
        "resource": resource,
        "decision": decision,
        "reason": reason,
        "policy": policy,
        "matched_rule": None,
        "matched_rule_basis": MATCHED_RULE_BASIS,
        "key_id": key_id,
    }
    if extra:
        # Namespaced so an added field can never collide with, or shadow, one
        # of the fields above that a verifier reads.
        body["gate_detail"] = dict(extra)
    body["signature_b64"] = base64.b64encode(sign(record_signing_bytes(body))).decode(
        "ascii"
    )
    return AuditRecord(body)


def verify_chain(
    records: list[AuditRecord],
    verify_signature: Callable[[bytes, bytes], bool],
) -> None:
    """Raise unless every record is validly signed AND the chain is unbroken.

    Checks, in order, and all of them: the sequence starts at 1 and increments
    by exactly one; each `prev_hash` equals the hash of the previous record's
    signature; each signature verifies over the record's own canonical bytes.

    An empty list raises. A verifier that returned "valid" for no records would
    report a cleared table as a healthy chain, which is the one answer a
    tamper-evidence check must never give.
    """
    if not records:
        raise AuditChainError(
            "no records to verify. An empty chain is not a valid chain: a "
            "cleared table must not read as healthy."
        )

    previous: AuditRecord | None = None
    for i, record in enumerate(records):
        expected_seq = i + 1
        if record.seq != expected_seq:
            raise AuditChainError(
                f"sequence break at position {i}: expected seq {expected_seq}, "
                f"found {record.seq}. A gap means a record was removed."
            )
        expected_prev = chain_hash(previous)
        actual_prev = record.body.get("prev_hash")
        if actual_prev != expected_prev:
            raise AuditChainError(
                f"chain break at seq {record.seq}: prev_hash is {actual_prev!r}, "
                f"expected {expected_prev!r}."
            )
        try:
            signature = base64.b64decode(record.signature_b64, validate=True)
        except Exception as exc:  # noqa: BLE001 - any decode failure is a bad record
            raise AuditChainError(
                f"seq {record.seq}: signature is not valid base64"
            ) from exc
        if not verify_signature(record_signing_bytes(record.body), signature):
            raise AuditChainError(
                f"seq {record.seq}: signature does not verify over the record's "
                "own bytes. The record was altered after signing."
            )
        previous = record
