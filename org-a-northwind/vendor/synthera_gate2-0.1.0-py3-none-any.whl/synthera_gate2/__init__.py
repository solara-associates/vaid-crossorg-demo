"""synthera-gate2 — receiver-side enforcement for a tool call.

Gate 2 decides whether a proposed tool call may run, against the policy the
caller's badge NAMES, and records the decision as chained signed evidence.

It runs at the receiver, on the receiver's own infrastructure, with the
receiver's own key. Nothing in the request path belongs to the issuer: the
issuer's public key, the revocation state and the policy bundle are all signed
artefacts that can be mirrored inside a private network, because a signature is
checked against bytes rather than against an origin.
"""

from synthera_gate2.audit import (
    GENESIS_PREV_HASH,
    MATCHED_RULE_BASIS,
    AuditChainError,
    AuditRecord,
    build_record,
    chain_hash,
    record_signing_bytes,
    verify_chain,
)
from synthera_gate2.decision import (
    BadgeVerification,
    BundleMirrorPort,
    Gate2Decision,
    InMemoryBundleMirror,
    Outcome,
    ToolCall,
    decide,
    run_tool_call,
)
from synthera_gate2.policy_ref import (
    POLICY_CAPABILITY_PREFIX,
    AmbiguousPolicyReference,
    MalformedPolicyReference,
    NoPolicyReference,
    PolicyRef,
    PolicyRefError,
    build_capability,
    is_policy_capability,
    parse_capability,
    policy_ref_from_badge,
)
from synthera_gate2.pop import (
    DEFAULT_FRESHNESS_SECONDS,
    InMemoryNonceStore,
    NonceStorePort,
    PopBadSignature,
    PopError,
    PopMissing,
    PopReplayed,
    PopStale,
    PopStoreUnavailable,
    verify_proof_of_possession,
)

__all__ = [
    "AmbiguousPolicyReference",
    "AuditChainError",
    "AuditRecord",
    "BadgeVerification",
    "BundleMirrorPort",
    "DEFAULT_FRESHNESS_SECONDS",
    "GENESIS_PREV_HASH",
    "Gate2Decision",
    "InMemoryBundleMirror",
    "InMemoryNonceStore",
    "MATCHED_RULE_BASIS",
    "MalformedPolicyReference",
    "NoPolicyReference",
    "NonceStorePort",
    "Outcome",
    "POLICY_CAPABILITY_PREFIX",
    "PolicyRef",
    "PolicyRefError",
    "PopBadSignature",
    "PopError",
    "PopMissing",
    "PopReplayed",
    "PopStale",
    "PopStoreUnavailable",
    "ToolCall",
    "build_capability",
    "build_record",
    "chain_hash",
    "decide",
    "is_policy_capability",
    "parse_capability",
    "policy_ref_from_badge",
    "record_signing_bytes",
    "run_tool_call",
    "verify_chain",
    "verify_proof_of_possession",
]

__version__ = "0.1.0"
